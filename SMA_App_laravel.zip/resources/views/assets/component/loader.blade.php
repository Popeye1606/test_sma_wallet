<div id="loader">
    <img src="<?php echo asset('img/logo.png') ?>" alt="icon" class="loading-icon w-50">
</div>