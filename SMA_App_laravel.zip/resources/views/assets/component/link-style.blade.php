<link rel="icon" type="image/png" href="{{ url('img/title.png') }}" sizes="32x32">
<link rel="apple-touch-icon" sizes="180x180" href="{{ url('img/icon/192x192.png') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
<link rel="manifest" href="./__manifest.json">

<!-- link google font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@500&display=swap" rel="stylesheet">