<h5 class="modal-title">Send</h5>
<?php /**PATH C:\xampp\htdocs\SMA_App_laravel\resources\views/assets/component/modal-send-header.blade.php ENDPATH**/ ?>