<?php $__env->startSection('content'); ?>
<!-- App Capsule -->
<div id="appCapsule">

    <div class="section mt-2 text-center">
        <h1>เข้าสู่ระบบ</h1>
        <h4>เข้าสู่ระบบ SMA Coin Wallet</h4>
    </div>
    <div class="section mb-5 p-2">

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>


            <div class="card">
                <div class="card-body pb-1">
                    <div class="form-group basic">
                        <div class="input-wrapper">
                            <label class="label" for="email">E-mail</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="Your Email" autofocus>
                            <i class="clear-input">
                                <ion-icon name="close-circle"></ion-icon>
                            </i>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group basic">
                        <div class="input-wrapper">
                            <label class="label" for="password">รหัสผ่าน</label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" required autocomplete="Your Password">
                            <i class="clear-input">
                                <ion-icon name="close-circle"></ion-icon>
                            </i>

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-links mt-1 mb-2">
                        <div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="remember">
                                    จดจำการเข้าสู่ระบบ
                                </label>
                            </div>
                        </div>
                        <div>
                            <?php if(Route::has('password.request')): ?>
                            <a href="forgot-password" class="text-muted" href="<?php echo e(route('password.request')); ?>">ลืมรหัสผ่าน ?</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>




            <div class="container text-center my-4">
                <div class="row">
                    <div class="col">
                        <h2>หรือ</h2>
                        <p>เข้าสู่ระบบด้วย</p>

                        <div class="row">

                            <div class="col text-center">
                                <div class="col py-1">
                                    <a href="<?php echo e(url('auth/facebook')); ?>">
                                        <img src="<?php echo e(asset('img/logosocial/facebook.png')); ?>" class="w-50" alt="">
                                    </a>
                                </div>
                                <div class="col py-1">
                                    <a href="http://">
                                        <img src="<?php echo e(asset('img/logosocial/google.png')); ?>" class="w-50" alt="">
                                    </a>
                                </div>
                                <div class="col py-1">
                                    <a href="http://">
                                        <img src="<?php echo e(asset('img/logosocial/line.png')); ?>" class="w-50" alt="">
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="form-button-group transparent">
                <a href="/register" type="button" class="btn btn-info">สมัครสมาชิก</a>
            </div>

            <div class="form-button-group transparent">
                <button type="submit" class="btn btn-primary btn-block btn-lg">เข้าสู่ระบบ</button>
            </div>

        </form>
    </div>

</div>
<!-- * App Capsule -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SMA_App_laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>